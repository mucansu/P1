package entities;

import se.mau.DA343A.VT25.assignment1.Direction;

public interface Move {
    void move(Direction direction);
}
