package entities;

public interface IPollution {
    void calculatePollution();
}
